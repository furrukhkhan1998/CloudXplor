package com.clxpr.demo.model.json;

public class DataStack {

	public DataStack(int userId, int mId, int o, String t, String to, int part, Long Id) {
		super();
		this.userId = userId;
		this.type = t;
		this.typeOutput = to;
		this.occurance = o;
		this.part = part;
		this.Id = Id;
		this.machineId = mId;
	}
	
	private Long Id;
	private int userId;
	private String type;
	private String typeOutput;
	private int part;
	private int occurance;
	private int machineId;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUsrId(int usrId) {
		this.userId = usrId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeOutput() {
		return typeOutput;
	}
	public void setTypeOutput(String typeOutput) {
		this.typeOutput = typeOutput;
	}
	public int getOccurance() {
		return occurance;
	}
	public void setOccurance(int occurance) {
		this.occurance = occurance;
	}
	public int getPart() {
		return part;
	}
	public void setPart(int part) {
		this.part = part;
	}
	public void setMachineId(int id) {
		this.machineId = id;
	}

	public int getMachineId() {
		return this.machineId;
	}

	
	
}
