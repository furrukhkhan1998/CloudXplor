package com.clxpr.demo.model.json;

public class DataThread {

	public DataThread(int userId, int occurance, int mId, String type, String output, int part, Long Id) {
		super();
		this.userId = userId;
		this.occurance = occurance;
		this.type = type;
		this.typeOutput = output;
		this.Id = Id;
		this.machineId = mId;
		this.part = part;
	}
	
	private Long Id;
	private int userId;
	private int occurance;
	private String type;
	private String typeOutput;
	private int part;
	private int machineId;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int usrId) {
		this.userId = usrId;
	}
	public int getOccurance() {
		return occurance;
	}
	public void setOccurance(int occurance) {
		this.occurance = occurance;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTypeOutput() {
		return typeOutput;
	}
	public void setTypeOutput(String typeOutput) {
		this.typeOutput = typeOutput;
	}
	public int getPart() {
		return part;
	}
	public void setPart(int part) {
		this.part = part;
	}
	public void setMachineId(int id) {
		this.machineId = id;
	}

	public int getMachineId() {
		return this.machineId;
	}

	
}
