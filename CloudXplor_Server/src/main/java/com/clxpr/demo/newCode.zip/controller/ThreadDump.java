package com.clxpr.demo.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

import com.clxpr.demo.model.json.DataThread;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ThreadDump {
	
	class PnS {
		
		class Thread {
			private String id;
			private String priority;
			private String state;
			
			Thread(String id, String p, String s) {
				this.id = id;
				this.priority = p;
				this.state = s;
			}
			
			
		}
		
		private String type;
		ArrayList <Thread> threads;
		
		PnS(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String output) {
			String[] arr = output.split(" ");
			this.threads.add(new Thread(arr[2], arr[4], arr[6]));
		}
	}
	
	class CT {
		
		class Thread {
			private String id;
			private String time;
			
			Thread(String id, String time) {
				this.id = id;
				this.time = time;
			}
		}
		
		private String type;
		ArrayList <Thread> threads;
		
		CT(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String type, String output) {
			String[] arr = type.split(" ");
			String[] arr2 = output.split(" ");
			this.threads.add(new Thread(arr[4], arr2[0]));
		}
		
		
	}
	
	class UT {
		
		class Thread {
			private String id;
			private String time;
			
			Thread(String id, String time) {
				this.id = id;
				this.time = time;
			}
		}
		
		private String type;
		ArrayList <Thread> threads;
		
		UT(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String type, String output) {
			String[] arr = type.split(" ");
			String[] arr2 = output.split(" ");
			this.threads.add(new Thread(arr[4], arr2[0]));
		}
		
	}
	
	class LR {
		
		class Thread {
			private String id;
			private ArrayList <String> monitors;
			
			Thread(String output) {
				String[] arr = output.split(", ");
				String[] arr2 = arr[0].split(" ");
				this.id = arr2[1];
				arr2 = arr[1].split(" ");
				for (int i = 0; i < arr2.length; i++)
					this.monitors.add(arr2[i]);
			}
		}
		
		private String type;
		private ArrayList <Thread> threads;
		
		LR(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String output) {
			this.threads.add(new Thread(output));
		}
		
	}
	
	class BC {
		
		class Thread {
			private String id;
			private String count;
			
			Thread(String output) {
				String[] arr = output.split(": ");
				this.id = arr[0];
				this.count = arr[1];
			}
		}
		
		private String type;
		private ArrayList <Thread> threads;
		
		BC(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String output) {
			this.threads.add(new Thread(output));
		}
		
	}
	
	class WC {
		
		class Thread {
			private String id;
			private String count;
			
			Thread(String output) {
				String[] arr = output.split(": ");
				this.id = arr[0];
				this.count = arr[1];
			}
		}
		
		private String type;
		private ArrayList <Thread> threads;
		
		WC(String type) {
			this.type = type;
			this.threads = new ArrayList <Thread> ();
		}
		
		void add(String output) {
			this.threads.add(new Thread(output));
		}
	}
	
	ArrayList <Object> getThreadObjects(ArrayList <DataThread> data) {
		ArrayList <Object> objects = new ArrayList <Object> ();
		PnS p = null;
		CT c = null;
		UT u = null;
		LR l = null;
		BC b = null;
		WC w = null;
		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).getType().contains("Priority")) {
				if (p == null) {
					p = new PnS(data.get(i).getType());
				}
				p.add(data.get(i).getTypeOutput());
			} else if (data.get(i).getType().contains("Cpu")) {
				if (c == null) {
					c = new CT(data.get(i).getType());
				}
				c.add(data.get(i).getType(), data.get(i).getTypeOutput());
			} else if (data.get(i).getType().contains("User Time")) {
				if (u == null) {
					u = new UT(data.get(i).getType());
				}
				u.add(data.get(i).getType(), data.get(i).getTypeOutput());
			} else if (data.get(i).getType().contains("Locked")) {
				if (l == null) {
					l = new LR(data.get(i).getType());
				}
				l.add(data.get(i).getTypeOutput());
			} else if (data.get(i).getType().contains("Blocked")) {
				if (b == null) {
					b = new BC(data.get(i).getType());
				}
				b.add(data.get(i).getTypeOutput()	);
			} else if (data.get(i).getType().contains("Wait")) {
				if (w == null) {
					w = new WC(data.get(i).getType());
				}
				w.add(data.get(i).getTypeOutput());
			}
		}
		if (p != null) 
			objects.add(p);
		if (c != null) 
			objects.add(c);
		if (u != null) 
			objects.add(u);
		if (l != null) 
			objects.add(l);
		if (b != null) 
			objects.add(b);
		if (w != null) 
			objects.add(w);
		
		return objects;
	}
	
	
	
	
	
}
