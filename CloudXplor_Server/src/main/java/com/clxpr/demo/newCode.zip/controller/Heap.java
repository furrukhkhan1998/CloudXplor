package com.clxpr.demo.controller;

import java.util.ArrayList;

import com.clxpr.demo.model.json.DataHeap;

public class Heap {
	
	class JavaClass {
		private String instances;
		private String memory;
		private String name;
		
		JavaClass(String i, String m, String n){
			this.name = n;
			this.instances = i;
			this.memory = m;
		}
	}
	
	ArrayList <Object> getHeapObjects(ArrayList <DataHeap> data) {
		ArrayList <Object> objects = new ArrayList <Object> ();
		
		for (int i = 0; i < data.size(); i++) {
			objects.add(new JavaClass(data.get(i).getInstance(), data.get(i).getMemory(), data.get(i).getClassName()));
		}
		
		return objects;
	}

}
