package com.clxpr.demo.controller;

import java.util.ArrayList;
import java.util.List;

import com.clxpr.demo.model.json.DataStack;

public class StackDump {
	
	class AMT {
		
		class Thread {
			
			class Method {
				String name;
				String caller;
				String file;
				String line;
				
				Method(String output) {
					String[] arr = output.split(" ");
					if (arr.length == 9) {
						this.line = "17";
						this.name = arr[0];
						this.caller = arr[5];
						this.file = arr[8];
					} else {
						this.name = arr[0];
						this.caller = arr[5];
						this.file = arr[12];
						this.line = arr[9];
					}
				}
			}
			
			private String id;
			private ArrayList <Method> methods;
			
			Thread(String type) {
				String[] arr = type.split(" ");
				this.id = arr[arr.length - 1];
				this.methods = new ArrayList <Method> ();
			}
			
			void add(String output) {
				this.methods.add(new Method(output));
			}
		}
		
		private String type;
		private Thread thread;
		
		AMT(String type) {
			this.type = "All Methods One Thread";
			this.thread = new Thread(type);
		}
		
		void add(String arg[]) {
			for (int i = 1; i < arg.length; i++)
				this.thread.add(arg[i]);
		}
		
	}
	
	class AMC {
		private String count;
		private String type;
		AMC(String type, String output) {
			this.count = output;
			this.type = type;
		}
	}
	
	class MC {
		private String name;
		private String count;
		private String type;
		
		MC(String type, String output) {
			this.type = "Method Count";
			this.count = output;
			this.name = type;
		}
	}
	
	class AMAT {
		
		private String type;
		private ArrayList <AMT> amt;
		
		AMAT(String type) {
			this.type = type;
		}
		
		void add(String output) {
			String[] arr = output.split(",");
			String[] arr2 = arr[1].split(" ");
			AMT amt = new AMT(arr[0]);
			amt.add(arr2);
		}
	}
	
	ArrayList <Object> getStackObjects(ArrayList <DataStack> data) {
		ArrayList <Object> objects = new ArrayList <Object> ();
		ArrayList <String> outputs = new ArrayList <String> ();
		AMT amt = new AMT("All Methods for thread"); 
		for (int i = 0; i < data.size(); i++) {
			if (data.get(i).getType().contains("All Methods for thread")) {
				amt = new AMT(data.get(i).getType());
				outputs.add(data.get(i).getTypeOutput());
			} else if (data.get(i).getType().contains("All Methods Count")) {
				objects.add(new AMC(data.get(i).getType(), data.get(i).getTypeOutput()));
			} else if (data.get(i).getType().contains("All Methods") == false) {
				objects.add(new MC(data.get(i).getType(), data.get(i).getTypeOutput()));
			} else if (data.get(i).getType().contains("All Methods All Threads")) {
				AMAT amat = getAMAT(data.subList(i, data.size()));
				objects.add(amat);
				break;
			}
		}
		if (outputs.size() > 0) {
			amt.add((String[]) outputs.toArray());
			objects.add(amt);
		}
		
		return objects;
	}
	
	AMAT getAMAT(List <DataStack> data) {
		AMAT amat = new AMAT(data.get(0).getType());
		int i = 0;
		String line = "";
		while (i < data.size()) {
			if (data.get(i).getTypeOutput().contains("Thread ID:") && line.length() == 0) {
				line = data.get(i).getTypeOutput() + ",";
			} else if (data.get(i).getTypeOutput().contains("Thread ID:") && line.length() != 0) {
				amat.add(line);
				line = "";
			} else {
				line = line + data.get(i).getTypeOutput() + " ";
			}
		}
		return amat;
	}

}
