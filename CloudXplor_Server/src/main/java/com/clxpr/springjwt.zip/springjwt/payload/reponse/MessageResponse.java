package com.clxpr.springjwt.payload.reponse;

public class MessageResponse {

}
