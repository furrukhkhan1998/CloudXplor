package com.clxpr.springjwt;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootReactMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootReactMysqlApplication.class, args);
	}

}