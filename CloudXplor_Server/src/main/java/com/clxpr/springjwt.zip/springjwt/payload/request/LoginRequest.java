package com.clxpr.springjwt.payload.request;

public class LoginRequest {

}
