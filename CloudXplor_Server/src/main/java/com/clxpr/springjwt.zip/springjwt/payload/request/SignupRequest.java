package com.clxpr.springjwt.payload.request;

public class SignupRequest {

}
